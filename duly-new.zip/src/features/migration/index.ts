import { ChainId } from '@sushiswap/sdk'

export const MigrationSupported = []
