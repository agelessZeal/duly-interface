import { default as Default } from './Default'
import { default as Kashi } from './Kashi'
import { default as Miso } from './Miso'

const Layout = { Default, Kashi, Miso }

export default Layout
